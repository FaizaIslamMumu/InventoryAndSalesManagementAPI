﻿using InventoryAndSalesManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;

namespace InventoryAndSalesManagementSystem.Context
{
    public class InventoryAndSalesDbContext : DbContext
    {
        public InventoryAndSalesDbContext(DbContextOptions<InventoryAndSalesDbContext> options) : base(options)
        {

        }
        public DbSet<Customer> Customers { get; set; } = default!;
        public DbSet<Order> Orders { get; set; } = default!;
        public DbSet<OrderItem> OrderItems { get; set; } = default!;
        public DbSet<Product> Products { get; set; } = default!;
        public DbSet<User> user { get; set; } = default!;
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<OrderItem>().HasKey(o => new { o.OrderID, o.ProductID });
        }
    }
}
