﻿using InventoryAndSalesManagementSystem.Repositories.Abstraction;

namespace InventoryAndSalesManagementSystem.Repositories.Abstraction
{
    public interface IUnitOfWork
    {
        IGenericRepo<T> GetRepo<T>() where T : class, new();
        Task CompleteAsync();
        void Dispose();
    }
}
