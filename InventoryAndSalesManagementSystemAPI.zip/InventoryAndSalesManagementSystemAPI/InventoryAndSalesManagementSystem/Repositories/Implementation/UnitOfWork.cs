﻿using InventoryAndSalesManagementSystem.Context;
using InventoryAndSalesManagementSystem.Models;
using InventoryAndSalesManagementSystem.Repositories.Abstraction;

namespace InventoryAndSalesManagementSystem.Repositories
{
    public class UnitOfWork : IUnitOfWork, IDisposable
    {
        InventoryAndSalesDbContext db;
        public UnitOfWork(InventoryAndSalesDbContext db)
        {
            this.db = db;
        }
        public async Task CompleteAsync()
        {
            await db.SaveChangesAsync();
        }

        public void Dispose()
        {
            this.db.Dispose();
        }

        public IGenericRepo<T> GetRepo<T>() where T : class, new()
        {
            return new GenericRepo<T>(this.db);
        }
    }
}
