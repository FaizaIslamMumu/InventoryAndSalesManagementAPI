﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using InventoryAndSalesManagementSystem.Models;
using InventoryAndSalesManagementSystem.Repositories.Abstraction;
using InventoryAndSalesManagementSystem.ViewModels;
using InventoryAndSalesManagementSystem.ViewModels.Input;
using Microsoft.AspNetCore.Authorization;

namespace InventoryAndSalesManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ProductsController : ControllerBase
    {

        private IWebHostEnvironment env;
        IUnitOfWork unitOfWork;
        IGenericRepo<Product> repo;
        public ProductsController(IUnitOfWork unitOfWork, IWebHostEnvironment env)
        {
            this.unitOfWork = unitOfWork;
            this.repo = this.unitOfWork.GetRepo<Product>();
            this.env = env;
        }

        // GET: api/Products
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetProducts()
        {
            var data = await this.repo.GetAllAsync();
            return data.ToList();
        }
        [HttpGet("VM")]
        public async Task<ActionResult<IEnumerable<ProductViewModel>>> GetProductViewModels()
        {
            var data = await this.repo.GetAllAsync(p => p.Include(x => x.OrderItems));
            return data.ToList().Select(p => new ProductViewModel
            {
                ProductID = p.ProductID,
                Price = p.Price,
                ProductName = p.ProductName,
                IsAvailable = p.IsAvailable,
                CanDelete = !p.OrderItems.Any(),


            }).ToList();
        }
        // GET: api/Products/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProduct(int id)
        {
            var product = await this.repo.GetAsync(x => x.ProductID == id);

            if (product == null)
            {
                return NotFound();
            }

            return product;
        }

        // PUT: api/Products/5

        //ApplyingStoreProcedure
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id, Product product)
        {
            {
                if (product == null)
                {
                    return BadRequest();
                }
                else
                {
                    var result = await repo.UpdateAsyncFromStoreProcedure(product);
                    if (result)
                    {
                        return Ok();
                    }
                    else
                    {
                        return BadRequest();
                    }
                }
            }
        }
        [HttpPut("{id}/VM")]
        public async Task<IActionResult> PutProductViewModel(int id, ProductInputModel product)
        {
            if (id != product.ProductID)
            {
                return BadRequest();
            }

            var existing = await this.repo.GetAsync(p => p.ProductID == id);
            if (existing != null)
            {
                existing.ProductName = product.ProductName;
                existing.Price = product.Price;
                existing.IsAvailable = product.IsAvailable;
                await this.repo.UpdateAsync(existing);
            }

            try
            {
                await this.unitOfWork.CompleteAsync();
            }
            catch (DbUpdateConcurrencyException)
            {

                throw;

            }

            return NoContent();
        }
        // POST: api/Products

        //ApplyingStoreProcedure
        [HttpPost]
        public async Task<ActionResult<Product>> PostProduct(Product product)
        {
            // Check if the product already exists
            var existingProduct = await this.repo.GetAsync(p => p.ProductName == product.ProductName);

            if (existingProduct != null)
            {
                return BadRequest("Product already exists!");
            }

            var result = await repo.AddAsyncFromStoreProcedure(product);

            if (result)
            {
                return Ok();
            }
            else
            {
                return BadRequest();
            }
        }



        [HttpPost("VM")]
        public async Task<ActionResult<Product>> PostProductInput(ProductInputModel product)
        {
            // Check if the product already exists
            var existingProduct = await this.repo.GetAsync(p => p.ProductName == product.ProductName);

            if (existingProduct != null)
            {
                return BadRequest("Product already exists!");
            }

            var newProduct = new Product
            {
                ProductName = product.ProductName,
                Price = product.Price,
                IsAvailable = product.IsAvailable
            };

            await this.repo.AddAsync(newProduct);
            await this.unitOfWork.CompleteAsync();

            return newProduct;
        }



        // DELETE: api/Products/5
        //ApplyingStoreProcedure
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }
            else
            {
                var result = await repo.DeleteAsyncFromStoreProcedure(id);
                if (result)
                {
                    return Ok();
                }
                else
                {
                    return BadRequest();
                }
            }
        }
    }


}

