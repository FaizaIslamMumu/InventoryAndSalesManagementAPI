﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using InventoryAndSalesManagementSystem.Helpers;
using InventoryAndSalesManagementSystem.Context;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using static System.Runtime.InteropServices.JavaScript.JSType;
using InventoryAndSalesManagementSystem.Models;

namespace ProductManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly InventoryAndSalesDbContext db;
        public UserController(InventoryAndSalesDbContext db)
        {
            this.db = db;
        }


        //login

        [HttpPost("LogIn")]
        public async Task<IActionResult> AuthenticateUser([FromBody] User userObj)
        {
            if (userObj == null)
                return BadRequest();

            var user = await db.user.FirstOrDefaultAsync(x => x.UserName == userObj.UserName);

            if (user == null)
                return NotFound(new { message = "User not found" });

            if (!PasswordHasher.VerifyPassword(userObj.Password, user.Password))
                return BadRequest(new { message = "Password is incorrect" });

            user.Token = CreateJwt(user);

            return Ok(new
            {
                token = user.Token,
                message = "Login success"
            });
        }


        //signup

        [HttpPost("SignUp")]
        public async Task<IActionResult> RegisterUser([FromBody] User userObj)
        {
            if (userObj == null)
                return BadRequest();

            //check username
            if (await CheckUserNameExistAsync(userObj.UserName))
                return BadRequest(new { message = "User name already exists" });

            //check email
            if (await CheckEmailExistAsync(userObj.Email))
                return BadRequest(new { message = "email already exists" });

            //check password strength
            var pass = CheckPasswordStrength(userObj.Password);
            if (!string.IsNullOrEmpty(pass))
                return BadRequest(new { message = pass.ToString() });

            userObj.Password = PasswordHasher.HashPassword(userObj.Password);
            //if (string.IsNullOrEmpty(userObj.Role))
            //{
            //    userObj.Role = "User";

            //}
            ////userObj.Role = "Super Admin";
            ////userObj.Role = "Admin";
            userObj.Role = "User";
            userObj.Token = "";
            await db.user.AddAsync(userObj);
            await db.SaveChangesAsync();
            return Ok(new { message = "User Registered" });
        }


        private Task<bool> CheckUserNameExistAsync(string username)
            => db.user.AnyAsync(x => x.UserName == username);

        private Task<bool> CheckEmailExistAsync(string email)
            => db.user.AnyAsync(x => x.Email == email);

        private string CheckPasswordStrength(string password)
        {
            StringBuilder sb = new StringBuilder();

            if (password.Length < 8)
                sb.Append("minimum password length should be 8" + Environment.NewLine);
            if (!(Regex.IsMatch(password, "[a-z]") && Regex.IsMatch(password, "[A-Z]") && Regex.IsMatch(password, "[0-9]")))
                sb.Append("password should be one alphaneumeric" + Environment.NewLine);
            if (!Regex.IsMatch(password, "[<,>,!,@,#,$,%,^,&,*,(,),\\[,\\],\\,/,.,',\",`,_,-]"))
                sb.Append("password should contain one special characters" + Environment.NewLine);

            return sb.ToString();
        }

        private string CreateJwt(User user)
        {
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes("supersecret.....");
            var identity = new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Role , user.Role),
                new Claim(ClaimTypes.Name, $"{user.FirstName} {user.LastName}")
            });

            var credentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = identity,
                Expires = DateTime.Now.AddDays(1),
                SigningCredentials = credentials
            };
            var token = jwtTokenHandler.CreateToken(tokenDescriptor);
            return jwtTokenHandler.WriteToken(token);
        }
    }
}
