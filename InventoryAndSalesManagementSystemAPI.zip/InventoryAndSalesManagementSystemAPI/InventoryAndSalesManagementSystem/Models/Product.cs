﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InventoryAndSalesManagementSystem.Models
{
    public class Product
    {
        public int ProductID { get; set; }
        [Required, StringLength(50), Display(Name = "Product Name")]
        public string ProductName { get; set; } = default!;
        [Required, Column(TypeName = "money"), DisplayFormat(DataFormatString = "{0:0.00}")]
        public decimal Price { get; set; }
        [Required]
        public bool IsAvailable { get; set; }
       
        public virtual ICollection<OrderItem> OrderItems { get;} = new List<OrderItem>();
    }
}
