﻿namespace InventoryAndSalesManagementSystem.Models
{
    public enum Status { Pending = 1, Delivered, Cancelled }
}
