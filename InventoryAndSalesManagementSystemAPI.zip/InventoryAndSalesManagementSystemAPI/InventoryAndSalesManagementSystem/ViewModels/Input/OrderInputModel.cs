﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using InventoryAndSalesManagementSystem.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InventoryAndSalesManagementSystem.ViewModels.Input
{
    public class OrderInputModel
    {
        [Required]
        public int OrderID { get; set; }
        [Required, DataType(DataType.Date)]
        public DateTime OrderDate { get; set; }
        [DataType(DataType.Date)]
        public DateTime? DeliveryDate { get; set; }
        [Required, EnumDataType(typeof(Status))]
        public Status Status { get; set; }
        [Required]
        public int CustomerID { get; set; }
        public List<OrderItem> OrderItems { get; } = default!;
    }
}
